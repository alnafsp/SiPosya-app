package com.siposya.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.siposya.app.data.model.SampleData
import com.siposya.app.navigation.Screen
import com.siposya.app.ui.components.*
import com.siposya.app.ui.theme.*

// ===================== NOTIFIKASI =====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotifikasiScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notifikasi", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = SoftBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${SampleData.notifikasiList.count { !it.sudahDibaca }} belum dibaca",
                    color = TextSoft, fontSize = 13.sp)
                TextButton(onClick = {}) {
                    Text("Tandai semua dibaca", color = Pink, fontWeight = FontWeight.Bold)
                }
            }
            SampleData.notifikasiList.forEach { notif ->
                NotifikasiRow(notif)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

// ===================== PROFIL =====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profil", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = SoftBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(Pink, Color(0xFFFF9EC7))))
                    .padding(24.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(Color.White.copy(0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👩", fontSize = 32.sp)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Ibu Sari Dewi", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("NIK: 3271xxxxxxxxxxxx", color = Color.White.copy(0.8f), fontSize = 13.sp)
                        Text("Posyandu Melati, Jakarta", color = Color.White.copy(0.8f), fontSize = 13.sp)
                    }
                }
            }

            // Data anak
            SiPosyaCard {
                SectionTitle("Data Anak", "👶")
                Spacer(modifier = Modifier.height(12.dp))
                ProfileRow("Nama Anak", "Zahra Putri")
                ProfileRow("Tanggal Lahir", "13 September 2025")
                ProfileRow("Usia", "7 Bulan")
                ProfileRow("Jenis Kelamin", "Perempuan")
                ProfileRow("Golongan Darah", "O")
            }

            // Menu profil
            SiPosyaCard {
                listOf(
                    "👤" to "Edit Profil",
                    "🔔" to "Pengaturan Notifikasi",
                    "📄" to "Riwayat Kunjungan",
                    "❓" to "Bantuan & FAQ",
                ).forEach { (emoji, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(emoji, fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("›", color = TextSoft, fontSize = 18.sp)
                    }
                    if (label != "Bantuan & FAQ") Divider(color = BorderColor)
                }
            }

            OutlineButton(
                text = "🚪 Keluar",
                onClick = { navController.navigate(Screen.Login.route) {
                    popUpTo(0)
                }},
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun ProfileRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSoft, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
    Divider(color = BorderColor)
}
