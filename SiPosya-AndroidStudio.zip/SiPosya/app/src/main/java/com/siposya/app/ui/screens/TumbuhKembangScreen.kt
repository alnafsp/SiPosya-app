package com.siposya.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.siposya.app.data.model.DataTumbuhKembang
import com.siposya.app.data.model.SampleData
import com.siposya.app.ui.components.*
import com.siposya.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TumbuhKembangScreen(navController: NavController) {
    val latestData = SampleData.dataTumbuhKembang.first()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tumbuh Kembang", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = SoftBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Stat terkini
            GradientHeader {
                Column {
                    Text("📏 Data Terkini", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("Zahra Putri · ${latestData.tanggal}", color = Color.White.copy(0.85f), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        StatItem("Berat", "${latestData.beratKg} kg")
                        StatItem("Tinggi", "${latestData.tinggiCm} cm")
                        StatItem("Status", "Normal ✓")
                    }
                }
            }

            // Grafik sederhana
            SiPosyaCard {
                SectionTitle("Grafik Berat Badan", "📈")
                Spacer(modifier = Modifier.height(14.dp))
                SimpleBarChart(data = SampleData.dataTumbuhKembang.reversed())
            }

            // Riwayat lengkap
            SiPosyaCard {
                SectionTitle("Riwayat Kunjungan", "📋")
                Spacer(modifier = Modifier.height(12.dp))
                SampleData.dataTumbuhKembang.forEach { data ->
                    TumbuhKembangRow(data)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        Text(label, color = Color.White.copy(0.8f), fontSize = 12.sp)
    }
}

@Composable
fun TumbuhKembangRow(data: DataTumbuhKembang) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFFFF8FB))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(PinkLight, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("📅", fontSize = 18.sp)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(data.tanggal, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(data.tempatPosyandu, color = TextSoft, fontSize = 12.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("${data.beratKg} kg", color = Pink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("${data.tinggiCm} cm", color = TextSoft, fontSize = 12.sp)
        }
    }
}

@Composable
fun SimpleBarChart(data: List<DataTumbuhKembang>) {
    val maxBerat = data.maxOf { it.beratKg }
    Row(
        modifier = Modifier.fillMaxWidth().height(120.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEach { item ->
            val heightFraction = (item.beratKg / maxBerat).toFloat()
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                Text("${item.beratKg}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Pink)
                Spacer(modifier = Modifier.height(2.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((100 * heightFraction).dp)
                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                        .background(Pink.copy(alpha = 0.7f + heightFraction * 0.3f))
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    item.tanggal.take(3),
                    fontSize = 9.sp,
                    color = TextSoft
                )
            }
        }
    }
}
