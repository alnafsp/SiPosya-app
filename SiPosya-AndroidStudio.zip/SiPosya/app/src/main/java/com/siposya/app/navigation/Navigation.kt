package com.siposya.app.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Home : Screen("home")
    object Antrian : Screen("antrian")
    object Imunisasi : Screen("imunisasi")
    object TumbuhKembang : Screen("tumbuh_kembang")
    object Notifikasi : Screen("notifikasi")
    object Profil : Screen("profil")
    // Petugas
    object PetugasDashboard : Screen("petugas_dashboard")
    object PetugasCatat : Screen("petugas_catat")
}
