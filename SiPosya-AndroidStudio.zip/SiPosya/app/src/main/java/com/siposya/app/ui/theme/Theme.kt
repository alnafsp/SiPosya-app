package com.siposya.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// === COLORS ===
val Pink = Color(0xFFFF6B9D)
val PinkLight = Color(0xFFFFE4F0)
val PinkDark = Color(0xFFE05588)
val BlueSoft = Color(0xFF6BCFFF)
val BlueLight = Color(0xFFE4F5FF)
val GreenPosya = Color(0xFF06D6A0)
val GreenLight = Color(0xFFE4FFF6)
val YellowAccent = Color(0xFFFFD166)
val YellowLight = Color(0xFFFFF3CD)
val SoftBg = Color(0xFFFFF5F9)
val CardBg = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF2D2D3A)
val TextSoft = Color(0xFF7A7A9A)
val BorderColor = Color(0xFFFFD6E7)

private val LightColorScheme = lightColorScheme(
    primary = Pink,
    onPrimary = Color.White,
    primaryContainer = PinkLight,
    onPrimaryContainer = PinkDark,
    secondary = GreenPosya,
    onSecondary = Color.White,
    secondaryContainer = GreenLight,
    background = SoftBg,
    surface = CardBg,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    outline = BorderColor,
)

val SiPosyaTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, color = TextPrimary),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, color = TextPrimary),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary),
    titleLarge = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = TextPrimary),
    titleMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 15.sp, color = TextPrimary),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 13.sp, color = TextSoft),
    labelSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 11.sp),
)

@Composable
fun SiPosyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = SiPosyaTypography,
        content = content
    )
}
