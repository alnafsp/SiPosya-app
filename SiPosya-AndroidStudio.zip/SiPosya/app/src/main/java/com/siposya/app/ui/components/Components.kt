package com.siposya.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.siposya.app.data.model.*
import com.siposya.app.ui.theme.*

@Composable
fun SiPosyaCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String, emoji: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 20.sp)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.titleLarge, fontSize = 17.sp)
    }
}

@Composable
fun StatCard(icon: String, value: String, label: String, valueColor: Color = Pink) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 24.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = valueColor)
            Text(label, fontSize = 11.sp, color = TextSoft, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun AntrianStatusBadge(status: AntrianStatus) {
    val (bg, fg, label) = when (status) {
        AntrianStatus.DIPANGGIL -> Triple(PinkLight, Pink, "▶ Dipanggil")
        AntrianStatus.MENUNGGU -> Triple(YellowLight, Color(0xFFB8860B), "⏳ Menunggu")
        AntrianStatus.SELESAI -> Triple(GreenLight, GreenPosya, "✓ Selesai")
    }
    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(50.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun AntrianRow(item: AntrianItem, isYou: Boolean = false) {
    val bgColor = when {
        item.status == AntrianStatus.DIPANGGIL -> Color(0xFFFFF0F6)
        isYou -> Color(0xFFFFF8FB)
        else -> Color.White
    }
    val alpha = if (item.status == AntrianStatus.SELESAI) 0.5f else 1f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.5.dp, BorderColor, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val badgeColor = when (item.status) {
            AntrianStatus.DIPANGGIL -> PinkLight
            AntrianStatus.SELESAI -> Color(0xFFF0F0F5)
            else -> BlueLight
        }
        val badgeText = when (item.status) {
            AntrianStatus.DIPANGGIL -> Pink
            AntrianStatus.SELESAI -> TextSoft
            else -> Color(0xFF3B9EF5)
        }
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(badgeColor, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(item.nomor, color = badgeText, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row {
                Text(
                    item.namaAnak,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary.copy(alpha = alpha)
                )
                if (isYou) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("← Anda", color = Pink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text("${item.usiaGroup} · ${item.sesi}", color = TextSoft, fontSize = 12.sp)
        }
        AntrianStatusBadge(item.status)
    }
}

@Composable
fun ImunisasiChip(item: ImunisasiItem) {
    val (bg, fg, prefix) = when (item.status) {
        ImunisasiStatus.SUDAH -> Triple(GreenLight, GreenPosya, "✓ ")
        ImunisasiStatus.AKAN_DATANG -> Triple(YellowLight, Color(0xFFB8860B), "⏳ ")
        ImunisasiStatus.BELUM -> Triple(PinkLight, Pink, "→ ")
    }
    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(50.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text("$prefix${item.nama}", color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GradientHeader(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(listOf(Pink, Color(0xFFFF9EC7)))
            )
            .padding(24.dp),
        content = content
    )
}

@Composable
fun NotifIcon(tipe: NotifTipe): Pair<String, Color> {
    return when (tipe) {
        NotifTipe.ANTRIAN -> Pair("📢", PinkLight)
        NotifTipe.IMUNISASI -> Pair("💉", GreenLight)
        NotifTipe.JADWAL -> Pair("📅", YellowLight)
        NotifTipe.INFO -> Pair("✅", BlueLight)
    }
}

@Composable
fun NotifikasiRow(item: NotifikasiItem) {
    val (emoji, bg) = NotifIcon(item.tipe)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (!item.sudahDibaca) Color(0xFFFFF5F9) else Color.White)
            .border(
                1.5.dp,
                if (!item.sudahDibaca) Pink else BorderColor,
                RoundedCornerShape(14.dp)
            )
            .padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .background(bg, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(emoji, fontSize = 18.sp)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(item.judul, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(item.isi, color = TextSoft, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(item.waktu, color = TextSoft, fontSize = 11.sp)
        }
        if (!item.sudahDibaca) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(Pink, CircleShape)
            )
        }
    }
}

@Composable
fun SesiCard(
    sesi: com.siposya.app.data.model.SesiAntrian,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) Pink else BorderColor
    val bgColor = if (isSelected) PinkLight else if (sesi.sisaSlot == 0) Color(0xFFF5F5F5) else Color.White

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(2.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable(enabled = sesi.sisaSlot > 0) { onClick() }
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(sesi.waktu, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp,
            color = if (sesi.sisaSlot == 0) TextSoft else TextPrimary)
        Text(sesi.label, color = TextSoft, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            if (sesi.sisaSlot > 0) "${sesi.sisaSlot} slot tersisa" else "Penuh",
            color = if (sesi.sisaSlot > 0) Pink else TextSoft,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier.height(50.dp),
        shape = RoundedCornerShape(50.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Pink)
    ) {
        Text(text, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }
}

@Composable
fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(50.dp),
        shape = RoundedCornerShape(50.dp),
        border = androidx.compose.foundation.BorderStroke(2.dp, Pink),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Pink)
    ) {
        Text(text, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }
}
