package com.siposya.app.data.model

// === ANTRIAN ===
data class AntrianItem(
    val nomor: String,
    val namaAnak: String,
    val usiaGroup: String,
    val sesi: String,
    val status: AntrianStatus
)

enum class AntrianStatus {
    MENUNGGU, DIPANGGIL, SELESAI
}

// === IMUNISASI ===
data class ImunisasiItem(
    val nama: String,
    val status: ImunisasiStatus
)

enum class ImunisasiStatus {
    SUDAH, AKAN_DATANG, BELUM
}

data class JadwalImunisasi(
    val periode: String,
    val usia: String,
    val items: List<ImunisasiItem>
)

// === TUMBUH KEMBANG ===
data class DataTumbuhKembang(
    val tanggal: String,
    val tempatPosyandu: String,
    val beratKg: Double,
    val tinggiCm: Double
)

// === NOTIFIKASI ===
data class NotifikasiItem(
    val id: Int,
    val judul: String,
    val isi: String,
    val waktu: String,
    val tipe: NotifTipe,
    val sudahDibaca: Boolean
)

enum class NotifTipe {
    ANTRIAN, IMUNISASI, JADWAL, INFO
}

// === SESI JADWAL ===
data class SesiAntrian(
    val waktu: String,
    val label: String,
    val sisaSlot: Int,
    val usiaGroup: String
)

// === ANAK ===
data class DataAnak(
    val nama: String,
    val tanggalLahir: String,
    val usiaBulan: Int,
    val jenisKelamin: String
)

// === SAMPLE DATA ===
object SampleData {

    val antrianList = listOf(
        AntrianItem("A-010", "Rina Kusuma", "0–1 thn", "08:00", AntrianStatus.SELESAI),
        AntrianItem("A-011", "Dina Rahma", "0–1 thn", "08:15", AntrianStatus.SELESAI),
        AntrianItem("A-012", "Sari Wijaya", "0–1 thn", "08:30", AntrianStatus.DIPANGGIL),
        AntrianItem("A-013", "Indah Lestari", "0–1 thn", "08:45", AntrianStatus.MENUNGGU),
        AntrianItem("A-014", "Zahra Putri", "0–1 thn", "09:00", AntrianStatus.MENUNGGU),
        AntrianItem("A-015", "Maya Pertiwi", "1–2 thn", "09:15", AntrianStatus.MENUNGGU),
        AntrianItem("B-001", "Arya Santosa", "1–2 thn", "09:30", AntrianStatus.MENUNGGU),
        AntrianItem("C-001", "Budi Pratama", "2–3 thn", "10:00", AntrianStatus.MENUNGGU),
    )

    val jadwalImunisasi = listOf(
        JadwalImunisasi("0 – 3 Bulan", "Bayi Baru Lahir", listOf(
            ImunisasiItem("Hepatitis B", ImunisasiStatus.SUDAH),
            ImunisasiItem("BCG", ImunisasiStatus.SUDAH),
            ImunisasiItem("Polio 0", ImunisasiStatus.SUDAH),
        )),
        JadwalImunisasi("2 – 4 Bulan", "Bayi 2 Bulan", listOf(
            ImunisasiItem("DPT-HB-Hib 1", ImunisasiStatus.SUDAH),
            ImunisasiItem("Polio 1", ImunisasiStatus.SUDAH),
            ImunisasiItem("Rotavirus", ImunisasiStatus.AKAN_DATANG),
        )),
        JadwalImunisasi("6 Bulan", "Bayi 6 Bulan", listOf(
            ImunisasiItem("DPT-HB-Hib 3", ImunisasiStatus.SUDAH),
            ImunisasiItem("PCV 3", ImunisasiStatus.BELUM),
            ImunisasiItem("Rotavirus 3", ImunisasiStatus.BELUM),
        )),
        JadwalImunisasi("9 Bulan", "Bayi 9 Bulan", listOf(
            ImunisasiItem("MR (Campak)", ImunisasiStatus.BELUM),
            ImunisasiItem("JE", ImunisasiStatus.BELUM),
        )),
        JadwalImunisasi("12 – 15 Bulan", "Batita", listOf(
            ImunisasiItem("PCV Booster", ImunisasiStatus.BELUM),
            ImunisasiItem("MR Booster", ImunisasiStatus.BELUM),
            ImunisasiItem("Varicella", ImunisasiStatus.BELUM),
        )),
        JadwalImunisasi("18 Bulan", "Batita", listOf(
            ImunisasiItem("DPT-HB-Hib 4", ImunisasiStatus.BELUM),
            ImunisasiItem("Polio 4", ImunisasiStatus.BELUM),
        )),
    )

    val dataTumbuhKembang = listOf(
        DataTumbuhKembang("Maret 2026", "Posyandu Melati", 7.2, 58.0),
        DataTumbuhKembang("Februari 2026", "Posyandu Melati", 6.8, 56.0),
        DataTumbuhKembang("Januari 2026", "Posyandu Melati", 6.3, 54.0),
        DataTumbuhKembang("Desember 2025", "Posyandu Melati", 5.9, 52.0),
        DataTumbuhKembang("November 2025", "Posyandu Melati", 5.5, 50.0),
    )

    val notifikasiList = listOf(
        NotifikasiItem(1, "Giliran hampir tiba!", "Antrian A-013 sedang dipanggil. Anda berikutnya (A-014). Segera ke ruang tunggu.", "2 menit lalu", NotifTipe.ANTRIAN, false),
        NotifikasiItem(2, "Imunisasi PCV 3 Jatuh Tempo", "Zahra Putri perlu imunisasi PCV 3 bulan ini. Jadwalkan segera.", "1 jam lalu", NotifTipe.IMUNISASI, false),
        NotifikasiItem(3, "Posyandu bulan depan", "Posyandu Melati akan buka Senin, 13 Mei 2026. Daftar antrian sudah dibuka.", "Kemarin", NotifTipe.JADWAL, true),
        NotifikasiItem(4, "Kunjungan Maret selesai", "Berat badan normal, tumbuh kembang baik. Lihat detail rekam medis.", "13 Mar 2026", NotifTipe.INFO, true),
    )

    val sesiPerUsia = mapOf(
        "0-1 Tahun" to listOf(
            SesiAntrian("08:00", "08:00 – 08:50", 1, "0-1 Tahun"),
            SesiAntrian("09:00", "09:00 – 09:50", 2, "0-1 Tahun"),
        ),
        "1-2 Tahun" to listOf(
            SesiAntrian("09:00", "09:00 – 09:50", 2, "1-2 Tahun"),
            SesiAntrian("10:00", "10:00 – 10:50", 4, "1-2 Tahun"),
        ),
        "2-3 Tahun" to listOf(
            SesiAntrian("10:00", "10:00 – 10:50", 3, "2-3 Tahun"),
            SesiAntrian("11:00", "11:00 – 11:30", 5, "2-3 Tahun"),
        ),
        "3-5 Tahun" to listOf(
            SesiAntrian("10:30", "10:30 – 11:30", 3, "3-5 Tahun"),
        ),
    )
}
