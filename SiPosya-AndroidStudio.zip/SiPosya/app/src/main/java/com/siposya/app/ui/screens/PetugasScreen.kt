package com.siposya.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.siposya.app.data.model.*
import com.siposya.app.navigation.Screen
import com.siposya.app.ui.components.*
import com.siposya.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetugasDashboardScreen(navController: NavController) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🌸", fontSize = 22.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("SiPosya", fontWeight = FontWeight.ExtraBold, color = Pink, fontSize = 16.sp)
                            Text("Mode Petugas", color = TextSoft, fontSize = 11.sp)
                        }
                    }
                },
                actions = {
                    TextButton(onClick = { navController.navigate(Screen.Login.route) { popUpTo(0) } }) {
                        Text("Keluar", color = Pink, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = SoftBg
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Tab bar
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = Pink
            ) {
                listOf("📋 Antrian", "📝 Catat Data").forEachIndexed { i, label ->
                    Tab(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        text = { Text(label, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            when (selectedTab) {
                0 -> AntrianManagementTab()
                1 -> CatatDataTab()
            }
        }
    }
}

@Composable
fun AntrianManagementTab() {
    var antrianList by remember { mutableStateOf(SampleData.antrianList.toMutableList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard("👶", "28", "Total Antrian", modifier = Modifier.weight(1f))
            StatCard("✅", "12", "Selesai", valueColor = GreenPosya, modifier = Modifier.weight(1f))
            StatCard("⏳", "16", "Menunggu", valueColor = Color(0xFFB8860B), modifier = Modifier.weight(1f))
        }

        // Sedang dilayani
        SiPosyaCard {
            Text("▶ Sedang Dilayani", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = Pink)
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(PinkLight)
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("A-012", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = Pink)
                    Text("Sari Wijaya · 0–1 thn · 08:30", color = TextSoft, fontSize = 13.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {},
                        colors = ButtonDefaults.buttonColors(containerColor = GreenPosya),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) { Text("✓ Selesai", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = {},
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) { Text("Lewati", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextSoft) }
                }
            }
        }

        // Daftar antrian
        SiPosyaCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionTitle("Daftar Antrian", "🗂")
                Button(
                    onClick = {},
                    colors = ButtonDefaults.buttonColors(containerColor = Pink),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("📣 Panggil Berikutnya", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(12.dp))

            SampleData.antrianList.filter { it.status != AntrianStatus.SELESAI }.forEach { item ->
                PetugasAntrianRow(item = item)
                Spacer(Modifier.height(8.dp))
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun PetugasAntrianRow(item: AntrianItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (item.status == AntrianStatus.DIPANGGIL) PinkLight else Color.White)
            .border(1.5.dp, BorderColor, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .background(PinkLight, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(item.nomor, color = Pink, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(item.namaAnak, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("${item.usiaGroup} · ${item.sesi}", color = TextSoft, fontSize = 11.sp)
        }
        if (item.status == AntrianStatus.DIPANGGIL) {
            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(containerColor = GreenPosya),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) { Text("✓ Done", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        } else {
            OutlinedButton(
                onClick = {},
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Pink),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) { Text("Panggil", color = Pink, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun CatatDataTab() {
    var berat by remember { mutableStateOf("") }
    var tinggi by remember { mutableStateOf("") }
    var lingkarKepala by remember { mutableStateOf("") }
    var suhu by remember { mutableStateOf("") }
    var catatan by remember { mutableStateOf("") }
    var imunisasiDipilih by remember { mutableStateOf("-- Pilih jika ada --") }
    var showSnackbar by remember { mutableStateOf(false) }

    val imunisasiOptions = listOf("-- Pilih jika ada --", "Hepatitis B", "BCG", "DPT-HB-Hib 1", "Polio 1", "PCV 1", "MR (Campak)")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SiPosyaCard {
            SectionTitle("Pilih Pasien", "👤")
            Spacer(Modifier.height(10.dp))
            SampleData.antrianList.filter { it.status == AntrianStatus.DIPANGGIL || it.status == AntrianStatus.MENUNGGU }
                .take(3).forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (item.status == AntrianStatus.DIPANGGIL) PinkLight else Color(0xFFF8F8FB))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(item.nomor, fontWeight = FontWeight.ExtraBold, color = Pink, fontSize = 13.sp)
                    Spacer(Modifier.width(10.dp))
                    Text(item.namaAnak, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(item.usiaGroup, color = TextSoft, fontSize = 12.sp)
                }
                Spacer(Modifier.height(6.dp))
            }
        }

        SiPosyaCard {
            SectionTitle("Catat Tumbuh Kembang", "📝")
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CatatField("Berat (kg)", berat, { berat = it }, Modifier.weight(1f))
                CatatField("Tinggi (cm)", tinggi, { tinggi = it }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CatatField("Lingkar Kepala (cm)", lingkarKepala, { lingkarKepala = it }, Modifier.weight(1f))
                CatatField("Suhu (°C)", suhu, { suhu = it }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Text("Imunisasi Diberikan", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            var expandedDropdown by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expandedDropdown, onExpandedChange = { expandedDropdown = it }) {
                OutlinedTextField(
                    value = imunisasiDipilih,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Pink, unfocusedBorderColor = BorderColor)
                )
                ExposedDropdownMenu(expanded = expandedDropdown, onDismissRequest = { expandedDropdown = false }) {
                    imunisasiOptions.forEach { opt ->
                        DropdownMenuItem(text = { Text(opt) }, onClick = { imunisasiDipilih = opt; expandedDropdown = false })
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Catatan Petugas", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = catatan,
                onValueChange = { catatan = it },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                placeholder = { Text("Kondisi anak, saran, dll.") },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Pink, unfocusedBorderColor = BorderColor)
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { showSnackbar = true },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GreenPosya)
            ) {
                Text("💾 Simpan Data", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            }
            if (showSnackbar) {
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(GreenLight)
                        .padding(12.dp)
                ) {
                    Text("✅ Data berhasil disimpan!", color = GreenPosya, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun CatatField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Pink, unfocusedBorderColor = BorderColor)
        )
    }
}

@Composable
fun StatCard(icon: String, value: String, label: String, modifier: Modifier = Modifier, valueColor: Color = Pink) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 22.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = valueColor)
            Text(label, fontSize = 10.sp, color = TextSoft, fontWeight = FontWeight.SemiBold)
        }
    }
}
