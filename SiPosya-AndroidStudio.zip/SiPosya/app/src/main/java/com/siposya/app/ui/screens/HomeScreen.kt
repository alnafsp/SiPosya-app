package com.siposya.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.siposya.app.data.model.SampleData
import com.siposya.app.navigation.Screen
import com.siposya.app.ui.components.*
import com.siposya.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🌸", fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SiPosya", fontWeight = FontWeight.ExtraBold, color = Pink)
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.Notifikasi.route) }) {
                        BadgedBox(badge = { Badge { Text("2") } }) {
                            Icon(Icons.Default.Notifications, contentDescription = "Notifikasi", tint = Pink)
                        }
                    }
                    IconButton(onClick = { navController.navigate(Screen.Profil.route) }) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Profil", tint = Pink)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = SoftBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Greeting
            GradientHeader {
                Column {
                    Text("Halo, Ibu! 👋", color = Color.White, fontSize = 13.sp)
                    Text("Zahra Putri", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .background(Color.White.copy(0.25f), RoundedCornerShape(50.dp))
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFFFFD166), RoundedCornerShape(50.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Antrian A-014 · 2 antrian lagi",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Menu utama
            Text("Menu Utama", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MenuCard("🎫", "Ambil\nAntrian", Modifier.weight(1f)) {
                    navController.navigate(Screen.Antrian.route)
                }
                MenuCard("⏱", "Status\nAntrian", Modifier.weight(1f)) {
                    navController.navigate(Screen.Antrian.route)
                }
                MenuCard("💉", "Imunisasi", Modifier.weight(1f)) {
                    navController.navigate(Screen.Imunisasi.route)
                }
                MenuCard("📏", "Tumbuh\nKembang", Modifier.weight(1f)) {
                    navController.navigate(Screen.TumbuhKembang.route)
                }
            }

            // Antrian terkini
            SiPosyaCard {
                SectionTitle("Status Antrian Sekarang", "⏱")
                Spacer(modifier = Modifier.height(12.dp))
                SampleData.antrianList.take(5).forEach { item ->
                    AntrianRow(item = item, isYou = item.nomor == "A-014")
                    Spacer(modifier = Modifier.height(8.dp))
                }
                OutlineButton(
                    text = "Lihat Semua Antrian",
                    onClick = { navController.navigate(Screen.Antrian.route) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Notifikasi preview
            SiPosyaCard {
                SectionTitle("Notifikasi Terbaru", "🔔")
                Spacer(modifier = Modifier.height(12.dp))
                SampleData.notifikasiList.take(2).forEach { notif ->
                    NotifikasiRow(notif)
                    Spacer(modifier = Modifier.height(8.dp))
                }
                OutlineButton(
                    text = "Lihat Semua",
                    onClick = { navController.navigate(Screen.Notifikasi.route) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun MenuCard(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 26.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
