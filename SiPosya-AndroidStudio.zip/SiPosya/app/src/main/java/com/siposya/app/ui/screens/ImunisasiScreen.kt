package com.siposya.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.siposya.app.data.model.SampleData
import com.siposya.app.ui.components.*
import com.siposya.app.ui.theme.SoftBg

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImunisasiScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Jadwal Imunisasi", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = SoftBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GradientHeader {
                Column {
                    Text("💉 Jadwal Imunisasi", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("Zahra Putri · 7 bulan", color = Color.White.copy(0.85f), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Pantau status imunisasi anak Anda agar tetap terlindungi", color = Color.White.copy(0.8f), fontSize = 12.sp)
                }
            }

            // Legend
            SiPosyaCard {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(
                        Triple("✓ Sudah", com.siposya.app.ui.theme.GreenLight, com.siposya.app.ui.theme.GreenPosya),
                        Triple("⏳ Segera", com.siposya.app.ui.theme.YellowLight, Color(0xFFB8860B)),
                        Triple("→ Belum", com.siposya.app.ui.theme.PinkLight, com.siposya.app.ui.theme.Pink),
                    ).forEach { (label, bg, fg) ->
                        androidx.compose.foundation.layout.Box(
                            modifier = Modifier
                                .background(bg, androidx.compose.foundation.shape.RoundedCornerShape(50.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            SampleData.jadwalImunisasi.forEach { jadwal ->
                SiPosyaCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(jadwal.periode, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            Text(jadwal.usia, color = com.siposya.app.ui.theme.TextSoft, fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        jadwal.items.forEach { item ->
                            ImunisasiChip(item)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
