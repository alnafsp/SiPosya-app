package com.siposya.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.siposya.app.navigation.Screen
import com.siposya.app.ui.screens.*
import com.siposya.app.ui.theme.SiPosyaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SiPosyaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SiPosyaApp()
                }
            }
        }
    }
}

@Composable
fun SiPosyaApp() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Login.route
    ) {
        composable(Screen.Login.route) {
            LoginScreen(navController)
        }
        composable(Screen.Home.route) {
            HomeScreen(navController)
        }
        composable(Screen.Antrian.route) {
            AntrianScreen(navController)
        }
        composable(Screen.Imunisasi.route) {
            ImunisasiScreen(navController)
        }
        composable(Screen.TumbuhKembang.route) {
            TumbuhKembangScreen(navController)
        }
        composable(Screen.Notifikasi.route) {
            NotifikasiScreen(navController)
        }
        composable(Screen.Profil.route) {
            ProfilScreen(navController)
        }
        composable(Screen.PetugasDashboard.route) {
            PetugasDashboardScreen(navController)
        }
    }
}
