package com.siposya.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.siposya.app.data.model.SampleData
import com.siposya.app.ui.components.*
import com.siposya.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AntrianScreen(navController: NavController) {
    var namaAnak by remember { mutableStateOf("Zahra Putri") }
    var usiaSelected by remember { mutableStateOf("0-1 Tahun") }
    var sesiSelected by remember { mutableStateOf<com.siposya.app.data.model.SesiAntrian?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var nomorAntrian by remember { mutableStateOf("") }

    val usiaOptions = listOf("0-1 Tahun", "1-2 Tahun", "2-3 Tahun", "3-5 Tahun")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Antrian Posyandu", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = SoftBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Antrian hero
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(Pink, Color(0xFFFF9EC7))),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Nomor Antrian Anda", color = Color.White.copy(0.9f), fontSize = 13.sp)
                    Text("A-014", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Kelompok 0–1 Tahun · Sesi 09:00", color = Color.White.copy(0.9f), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .background(Color.White.copy(0.25f), RoundedCornerShape(50.dp))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(8.dp).background(Color(0xFFFFD166), RoundedCornerShape(50.dp)))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Sedang dilayani: A-012 · 2 antrian lagi",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Form ambil antrian
            SiPosyaCard {
                SectionTitle("Ambil Nomor Antrian", "🎫")
                Spacer(modifier = Modifier.height(14.dp))

                Text("Nama Anak", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = namaAnak,
                    onValueChange = { namaAnak = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    placeholder = { Text("Contoh: Budi Santoso") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Pink,
                        unfocusedBorderColor = BorderColor
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text("Kelompok Usia", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    usiaOptions.forEach { usia ->
                        FilterChip(
                            selected = usiaSelected == usia,
                            onClick = {
                                usiaSelected = usia
                                sesiSelected = null
                            },
                            label = { Text(usia, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PinkLight,
                                selectedLabelColor = Pink
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                Text("Pilih Sesi", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))
                val sesiList = SampleData.sesiPerUsia[usiaSelected] ?: emptyList()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    sesiList.forEach { sesi ->
                        Box(modifier = Modifier.weight(1f)) {
                            SesiCard(
                                sesi = sesi,
                                isSelected = sesiSelected == sesi,
                                onClick = { sesiSelected = sesi }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                PrimaryButton(
                    text = "🎫 Ambil Nomor Antrian",
                    onClick = {
                        if (namaAnak.isNotBlank() && sesiSelected != null) {
                            nomorAntrian = "A-0${(15..25).random()}"
                            showDialog = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Status antrian real-time
            SiPosyaCard {
                SectionTitle("Status Antrian Real-time", "⏱")
                Spacer(modifier = Modifier.height(12.dp))
                SampleData.antrianList.forEach { item ->
                    AntrianRow(item = item, isYou = item.nomor == "A-014")
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Dialog konfirmasi antrian
    if (showDialog) {
        Dialog(onDismissRequest = { showDialog = false }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🎉", fontSize = 48.sp)
                    Text("Nomor Antrian Berhasil!", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        nomorAntrian,
                        fontSize = 52.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Pink
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "$namaAnak terdaftar pada sesi ${sesiSelected?.label ?: ""}.\nHarap tiba 10 menit sebelum jadwal.",
                        color = TextSoft,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlineButton("Tutup", onClick = { showDialog = false }, modifier = Modifier.weight(1f))
                        PrimaryButton("Simpan Tiket", onClick = { showDialog = false }, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
